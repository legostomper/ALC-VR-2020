﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Zenva.VR
{
    public class ShortNotice : MonoBehaviour
    {
        // Start is called before the first frame update
        void Start()
        {

        }

        
    }
}